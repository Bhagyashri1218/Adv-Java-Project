package com.supermarket.cntr;



import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;


import com.supermarket.dto.Cart;
import com.supermarket.dto.Product;
import com.supermarket.dto.User;
import com.supermarket.service.UserService;
import com.supermarket.valid.UserValidator;
import com.supermarket.valid.loginValidator;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private loginValidator logValidator;
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private MailSender mailSender;
	
	@RequestMapping(value="/prep_add_form.htm", method = RequestMethod.GET)
	public String prepAddForm(ModelMap map)
	{
		map.put("user", new User());
		
		return "add_form";
	}
	
	@RequestMapping(value="/prep_reg_form.htm", method = RequestMethod.GET)
	public String prepRegForm(ModelMap map)
	{
		map.put("user", new User());
		
		return "reg_form";
	}
	
	
	@RequestMapping(value="/reg.htm",method = RequestMethod.POST)
	public String register(User user,BindingResult result,ModelMap map,HttpSession session) {
		/*userValidator.validate(user, result);
		if(result.hasErrors())
		{
			return "reg_form";
		}*/
		
		userValidator.validate(user, result);
		if(result.hasErrors()) {
			//map.put("user", new User());
			return "reg_form";
		}
		
		userService.addUser(user);
		return "index";
		
		
		
	}
	
	@RequestMapping(value="/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map)
	{
		map.put("user",new User());
		return "login_form";
	}
	
	@RequestMapping(value="/login.htm", method=RequestMethod.POST)
	public String login(User user,BindingResult result,ModelMap map,HttpSession session)
	{
		
		logValidator.validate(user, result);
		if(result.hasErrors()) {
			//map.put("user", new User());
			return "login_form";
		}
		
		boolean b=userService.findUser(user);
		if(b)
		{
			User ur=userService.findUserDetails(user);
			//System.out.print(ur.getUserId());
			String pass=user.getUserPass();
			if(pass.compareTo("@214214")==0)
			{
				session.setAttribute("user", ur);
				return "home_admin";
			}
			else
			{
				session.setAttribute("user", ur);
				return "home";
			}
		}
		else 
		{
			map.put("user", new User());
			return "login_form";
		}
	}
	
	@RequestMapping(value="/prep_grocery_form.htm",method=RequestMethod.GET)
	public String grocery(Product product,ModelMap map)
	{
		product.setProductType("Grocery");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "grocery_list";
		
	}
	
	@RequestMapping(value="/prep_electric_form.htm",method=RequestMethod.GET)
	public String electric(Product product,ModelMap map)
	{
		product.setProductType("Electric");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "electric_list";
		
	}
	
	
	@RequestMapping(value="/prep_electronic_form.htm",method=RequestMethod.GET)
	public String electronic(Product product,ModelMap map)
	{
		product.setProductType("Electronic");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "electronic_list";
		
	}
	
	@RequestMapping(value="/add_to_card_grocery.htm",method = RequestMethod.GET)
	public String addToCard(@RequestParam String productId,@RequestParam float price,@RequestParam String productName,@RequestParam int qty,User user,Product product,Cart cart,ModelMap map,HttpSession session)
	{			
		int userId=((User)session.getAttribute("user")).getUserId();
		//String productName=((Product)session.getAttribute("product")).getProductName();
		//System.out.println(userId);
		// Product Add to Cart
		userService.addToCard(userId,productName,product,cart,qty);		
	
		product.setProductType("Grocery");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "grocery_list";
		
	}
	
	@RequestMapping(value="/add_to_card_electronic.htm",method=RequestMethod.GET)
	public String addToCart(@RequestParam String productId,@RequestParam float price,@RequestParam String productName,@RequestParam int qty,User user,Product product,Cart cart,ModelMap map,HttpSession session)
	{
		int userId=((User)session.getAttribute("user")).getUserId();
		userService.addToCard(userId,productName,product,cart,qty);		
		
		product.setProductType("Electronic");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "electronic_list";
	}
	@RequestMapping(value = "/add_to_card_electric.htm", method = RequestMethod.GET)
	public String addToCartE(@RequestParam String productId,@RequestParam float price,@RequestParam String productName,@RequestParam int qty,User user,Product product,Cart cart,ModelMap map,HttpSession session)
	{
		int userId=((User)session.getAttribute("user")).getUserId();
		userService.addToCard(userId,productName,product,cart,qty);		
		
		product.setProductType("Electric");
		List<Product> li=userService.findItem(product);
		map.put("proList", li);
		return "electric_list";
	}
	
	
	@RequestMapping(value="/logout.htm",method = RequestMethod.GET)
	public String addToCard(ModelMap map,HttpSession session)
	{	
		session.removeAttribute("user");
		map.put("user",new User());
		return "index";
		
	}
	
	@RequestMapping(value="/prep_cart_form.htm",method=RequestMethod.GET)
	public String cart(ModelMap map,User user,Product product, HttpSession session)
	{
		int userId=((User)session.getAttribute("user")).getUserId();
		List<Cart>list=userService.findUserItem(userId);
		map.put("prodList", list);
		return "userItem_list";
		
	}
	
	@RequestMapping(value="/item_delete.htm")
	public String deleteItem(@RequestParam int cartId,User user,ModelMap map,HttpSession session)
	{
		userService.removeItem(cartId);
		int userId=((User)session.getAttribute("user")).getUserId();
		List<Cart>list=userService.findUserItem(userId);
		map.put("prodList", list);
		return "userItem_list";
		
	}
	
	@RequestMapping(value="/item_update_form.htm")
	public String updateItemForm(@RequestParam int cartId,User user,ModelMap map,HttpSession session)
	{
		
		Cart cart=userService.selectModifyItem(cartId);
		map.put("cartItem", cart);
		return "modify_cartItem";
		
	}
	@RequestMapping(value="item_update.htm")
	public String updateItem(Cart cart,ModelMap map,HttpSession session)
	{
		int userId=((User)session.getAttribute("user")).getUserId();
		List<Cart> list=userService.modifyItem(cart,userId);
		map.put("prodList",list );
		return "userItem_list";
		
	}
	
	
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String userEmail,ModelMap map) {		
		String pass = userService.forgotPassword(userEmail);
		
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("bhagyadeore12@gmail.com");  
	        message.setTo(userEmail);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	       // MailSender mailSender;
			//sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info";
	}
	
	@RequestMapping(value = "select_customer.htm",method = RequestMethod.GET)
	public String allCustomer(ModelMap map,HttpSession session)
	{
		List<User> li = userService.selectAllUser();
		map.put("userList", li);
		return "user_list";
	}
	
	@RequestMapping(value="/prep_add_form1.htm", method = RequestMethod.GET)
	public String prepAddForm1(ModelMap map)
	{
		map.put("user", new User());
		
		return "customer_add_form";
	}
	
	
	
	@RequestMapping(value="/reg1.htm",method = RequestMethod.POST)
	public String register1(User user,BindingResult result,ModelMap map,HttpSession session) {
		/*userValidator.validate(user, result);
		if(result.hasErrors())
		{
			return "reg_form";
		}*/
		
		userValidator.validate(user, result);
		if(result.hasErrors()) {
			//map.put("user", new User());
			return "reg_form";
		}
		
		userService.addUser(user);
		return "customer";
}
}
