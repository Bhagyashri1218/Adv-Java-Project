package com.supermarket.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.validation.BindingResult;


import com.supermarket.dto.Product;
import com.supermarket.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService productService;
	
	@RequestMapping(value="/prep_product_add_form.htm",method = RequestMethod.GET)
	public String prepProductAddForm(ModelMap map)
	{
		map.put("product",new Product());
		return "product_add_form";
		
	}
	@RequestMapping(value="/product_add.htm",method = RequestMethod.POST)
	public String productAdd(Product product,HttpSession session)
	{
		productService.addProduct(product);
		return "home_admin";
	}
	
	
	@RequestMapping(value="/prep_all_product_form.htm",method = RequestMethod.GET)
	public String allProduct(ModelMap map,HttpSession session)
	{
		List<Product> li = productService.selectAll();
		map.put("proList", li);
		return "product_list";
	}
	
	
	@RequestMapping(value="/product_delete.htm",method = RequestMethod.GET)
	public String deleteProduct(@RequestParam int productId,ModelMap map,HttpSession session)
	{
		productService.removeProduct(productId);
		List<Product> li = productService.selectAll();
		map.put("proList", li);
		return "product_list";
	
	}
	
	@RequestMapping(value="/product_update_form.htm")
	public String productUpdateForm(@RequestParam int productId,ModelMap map,HttpSession session)
	{
		Product pro=productService.findProduct(productId);
		map.put("product", pro);
		return "product_update_form";
	}
	@RequestMapping(value = "/product_update.htm",method = RequestMethod.POST)
	public String productUpdate(Product product,ModelMap map,HttpSession session)
	{
		productService.modifyProduct(product);
		List<Product> li=productService.selectAll();
		
		map.put("proList", li);
		return "product_list";
	}
}

