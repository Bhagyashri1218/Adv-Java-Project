package com.supermarket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supermarket.dao.UserDao;
import com.supermarket.dto.Cart;
import com.supermarket.dto.Product;
import com.supermarket.dto.User;

@Service
public class UserServiceImple implements UserService {
	
	@Autowired
	private UserDao userDao;
	@Override
	public void addUser(User user) {
		userDao.insertUser(user);
	}
	@Override
	public boolean findUser(User user) {
		
		return userDao.checkUser(user);
	}
	@Override
	public List<Product> findItem(Product product) {
		
		return userDao.selectItem(product);
	}

	
	@Override
	public void addToCard(int userId,String productName, Product product, Cart cart, int qty) {
		
		userDao.insertToCard(userId,productName, product, cart, qty);
	}
	
	@Override
	public User findUserDetails(User user) {
		return userDao.selectUserDetails(user);
		
	}
	@Override
	public List<Cart> findUserItem(int userId) {
		
		return userDao.selectUserItem(userId);
	}
	@Override
	public void removeItem(int cartId) {
		userDao.deleteItem(cartId);
		
	}
	@Override
	public Cart selectModifyItem(int cartId) {
		
		return userDao.selectUpdateItem(cartId);
	}
	@Override
	public List<Cart> modifyItem(Cart cart,int userId) {
		
		return userDao.updateItem(cart,userId);
	}
	
	@Override
	public String forgotPassword(String userEmail) {
		return userDao.forgotPassword(userEmail);
	}
	@Override
	public List<User> selectAllUser() {
		
		return userDao.selectAll();
	}
}
