package com.supermarket.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="product")
public class Product {
	 @Id
	 @GeneratedValue
	 @Column(name="product_id")
	 private int productId;
	 @Column(name="product_name")
	 private String productName;
	 private float price;
	 @Column(name="add_date")
	 private String addDate;
	 @Column(name="product_type")
	 private String productType;
	 @Transient
	 private int qty;
	
	 

	public Product(String productType) {
		super();
		this.productType = productType;
	}

	public Product() {
		super();
	}
	
	public Product(int productId) {
		
		this.productId = productId;
	}
	
	
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}
	 
	public String getItemName(int productId)
	{
		return getProductName();
	}
}
